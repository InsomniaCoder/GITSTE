package com.xom.plm.document.proxy.implementation;

import com.xom.plm.document.proxy.HttpAdapter;
import com.xom.plm.document.proxy.SAPAdapter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;

/**
 * Created by tlokeja on 8/7/2017.
 */
@Service
public class SAPAdapterImpl implements SAPAdapter {

    private static final String X_CSRF_TOKEN = "X-CSRF-Token";
    private static final String ACCEPT = "Accept";
    private static final String AUTHORIZATION = "Authorization";
    private static final String FETCH = "Fetch";

    private final HttpAdapter httpAdapter;

    private final String sapGetXCSRFTokenRestURL;
    private final String encodedRestServiceId;

    private final Logger log = LoggerFactory.getLogger(this.getClass());

    @Autowired
    public SAPAdapterImpl(HttpAdapter httpAdapter,
                          @Value("${sap.api.authorization.basic.rest}") String encodedRestServiceId,
                          @Value("${sap.api.url.xcsrf-token-rest}") String sapGetXCSRFTokenRestURL) {

        this.httpAdapter = httpAdapter;
        this.encodedRestServiceId = encodedRestServiceId;
        this.sapGetXCSRFTokenRestURL = sapGetXCSRFTokenRestURL;
    }

    @Override
    public HttpHeaders createBasicSAPHeader() {
        HttpHeaders defaultHeader = new HttpHeaders();
        defaultHeader.add(ACCEPT, MediaType.APPLICATION_JSON_VALUE);
        defaultHeader.add(AUTHORIZATION, "Basic " + this.encodedRestServiceId);
        return defaultHeader;
    }

    @Override
    public HttpHeaders createTokenSAPHeader() {
        HttpHeaders fetchTokenHeader = createBasicSAPHeader();
        fetchTokenHeader.add(X_CSRF_TOKEN, FETCH);

        HttpEntity<String> fetchTokenEntity = new HttpEntity<>(fetchTokenHeader);

        ResponseEntity<String> tokenResponse = (ResponseEntity<String>) httpAdapter.call(this.sapGetXCSRFTokenRestURL,
                HttpMethod.GET, fetchTokenEntity, String.class);

        String token = tokenResponse.getHeaders().getFirst(X_CSRF_TOKEN);
        log.info("received x-csrf token : {}", token);

        HttpHeaders tokenSAPHeader = createBasicSAPHeader();
        tokenSAPHeader.add(X_CSRF_TOKEN, token);
        return tokenSAPHeader;
    }
}
