package com.xom.plm.document.model.json;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.hibernate.validator.constraints.NotBlank;

import javax.validation.constraints.NotNull;

/**
 * Created by tlokeja on 8/7/2017.
 */
public class Document {

    @JsonProperty("DOCUMENTTYPE")
    @NotNull
    @NotBlank
    private String documentType;

    @JsonProperty("DOCUMENTNUMBER")
    @NotNull
    @NotBlank
    private String documentNumber;

    @JsonProperty("DOCUMENTPART")
    @NotNull
    private String documentPart;

    @JsonProperty("DOCUMENTVERSION")
    @NotNull
    private String documentVersion;

    public Document() {

    }

    public Document(String documentType, String documentNumber) {
        this.documentType = documentType;
        this.documentNumber = documentNumber;
    }

    public String getDocumentNumber() {
        return documentNumber;
    }

    public void setDocumentNumber(String documentNumber) {
        this.documentNumber = documentNumber;
    }

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    public String getDocumentPart() {
        return documentPart;
    }

    public void setDocumentPart(String documentPart) {
        this.documentPart = documentPart;
    }

    public String getDocumentVersion() {
        return documentVersion;
    }

    public void setDocumentVersion(String documentVersion) {
        this.documentVersion = documentVersion;
    }
}
