package com.xom.plm.document.proxy.implementation;

import com.xom.plm.document.proxy.HttpAdapter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

/**
 * Created by tlokeja on 8/9/2017.
 */
@Component
public class HttpAdapterImpl implements HttpAdapter {

    private final RestTemplate restTemplate;

    @Autowired
    public HttpAdapterImpl(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @Override
    public ResponseEntity<?> call(String url, HttpMethod method, HttpEntity entity, Class classes) throws HttpClientErrorException {
        return restTemplate.exchange(url, method, entity, classes);
    }
}
