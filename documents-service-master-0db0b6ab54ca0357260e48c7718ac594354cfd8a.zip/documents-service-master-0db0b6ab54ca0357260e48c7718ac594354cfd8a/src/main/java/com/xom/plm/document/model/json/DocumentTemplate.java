package com.xom.plm.document.model.json;

import java.util.List;

/**
 * Created by tlokeja on 8/7/2017.
 */
public class DocumentTemplate {

    private String type;
    private List<Document> documents = null;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<Document> getDocuments() {
        return documents;
    }

    public void setDocuments(List<Document> documents) {
        this.documents = documents;
    }
}
