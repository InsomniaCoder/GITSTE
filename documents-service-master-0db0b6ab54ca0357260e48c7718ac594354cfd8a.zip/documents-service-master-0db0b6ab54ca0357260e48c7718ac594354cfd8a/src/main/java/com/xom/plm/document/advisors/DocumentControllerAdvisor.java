package com.xom.plm.document.advisors;

import com.xom.plm.document.controller.DocumentController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

/**
 * Created by csuttic on 12/27/2017.
 */
@ControllerAdvice(assignableTypes = DocumentController.class)
public class DocumentControllerAdvisor extends ResponseEntityExceptionHandler {

    private final Logger log = LoggerFactory.getLogger(this.getClass());

    @ExceptionHandler(value = {HttpClientErrorException.class})
    public ResponseEntity<String> handleHttpClientErrorException(HttpClientErrorException e) {
        log.error("HttpClientErrorException : " + e.getMessage() + "");
        log.error("stack  : " + e.getRootCause() + "  " + e.getCause());
        return new ResponseEntity<String>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
    }

   /* @ExceptionHandler(value = {ClassCastException.class})
    public ResponseEntity<String> handleClassCastException(ClassCastException e){
        log.error("HttpClientErrorException : " + e.getMessage() + "");
        log.error("stack  : " + e.getCause());
        return new ResponseEntity<String>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
    }
*/
    @ExceptionHandler(value = {Exception.class})
    public ResponseEntity<String> handleException(Exception e) {
        log.error("Unknown exception thrown : " + e.getMessage());
        log.error("stack  : " + e.getCause());
        return new ResponseEntity<String>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
    }

}
