package com.xom.plm.document.model.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.hibernate.validator.constraints.NotBlank;

import javax.validation.constraints.NotNull;

/**
 * Created by tlokeja on 9/12/2017.
 */
public class CreateAndLinkRequest {

    @JsonProperty("template")
    @NotNull
    @NotBlank
    private DocumentTemplate template;

    @JsonProperty("link_objectkey")
    @NotNull
    @NotBlank
    private String objectGuid;

    public CreateAndLinkRequest() {
    }

    public CreateAndLinkRequest(DocumentTemplate template, String objectGuid) {
        this.template = template;
        this.objectGuid = objectGuid;
    }

    public DocumentTemplate getTemplate() {
        return template;
    }

    public void setTemplate(DocumentTemplate template) {
        this.template = template;
    }

    public String getObjectGuid() {
        return objectGuid;
    }

    public void setObjectGuid(String objectGuid) {
        this.objectGuid = objectGuid;
    }
}
