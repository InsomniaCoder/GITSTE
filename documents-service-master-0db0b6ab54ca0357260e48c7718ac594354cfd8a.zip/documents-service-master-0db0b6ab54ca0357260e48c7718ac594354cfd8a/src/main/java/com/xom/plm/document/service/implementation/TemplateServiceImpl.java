package com.xom.plm.document.service.implementation;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.xom.plm.document.model.json.Document;
import com.xom.plm.document.model.json.DocumentTemplate;
import com.xom.plm.document.service.TemplateService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by tlokeja on 8/7/2017.
 */
@Service
public class TemplateServiceImpl implements TemplateService {

    private List<DocumentTemplate> documentTemplates;

    private final Logger log = LoggerFactory.getLogger(this.getClass());

    @Autowired
    public TemplateServiceImpl(@Value("${json.template.filename}") String templateFileName, ObjectMapper objectMapper) throws IOException, URISyntaxException {

        log.info(templateFileName);

        ClassLoader classLoader = getClass().getClassLoader();
        this.documentTemplates = objectMapper.readValue(classLoader.getResourceAsStream(templateFileName),
                objectMapper.getTypeFactory().constructCollectionType(List.class, DocumentTemplate.class));
    }

    /**
     * Find list of documents using document type
     *
     * @param documentType like Z001, Z006
     * @return documents list of document type
     */
    @Override
    public List<Document> getDocumentListFromDocumentType(String documentType) {

        List<DocumentTemplate> templates = this.documentTemplates.stream()
                .filter(documentTemplate -> documentTemplate.getType().equalsIgnoreCase(documentType))
                .collect(Collectors.toList());

        int foundTemplateListSize = templates.size();

        if (foundTemplateListSize == 0) {
            log.debug("given document type : " + documentType + " has no record in template. returns empty list of documents");
            return new ArrayList<>();
        }

        DocumentTemplate matchedDocument = templates.get(0);
        return matchedDocument.getDocuments();
    }
}
