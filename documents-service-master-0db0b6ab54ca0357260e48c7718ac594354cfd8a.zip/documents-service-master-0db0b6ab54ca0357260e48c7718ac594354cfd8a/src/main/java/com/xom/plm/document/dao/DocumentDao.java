package com.xom.plm.document.dao;

import com.xom.plm.document.model.json.Document;
import com.xom.plm.document.model.request.CreateAndLinkRequest;
import org.springframework.web.client.HttpClientErrorException;

/**
 * Created by tlokeja on 9/13/2017.
 */
public interface DocumentDao {

    Document createAndLinkDocument(CreateAndLinkRequest request) throws HttpClientErrorException;

    void checkInDocument(String documentType, String documentNumber, String fileId);
}
