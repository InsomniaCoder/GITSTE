package com.xom.plm.document.model.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.hibernate.validator.constraints.NotBlank;

import javax.validation.constraints.NotNull;

/**
 * Created by tlokeja on 8/2/2017.
 */
public class CreateDocumentsRequest {

    @JsonProperty("ITEM_GUID")
    @NotNull
    @NotBlank
    private String itemGuid;

    @JsonProperty("ITEM_TYPE")
    @NotNull
    @NotBlank
    private String itemType;

    public String getItemGuid() {
        return itemGuid;
    }

    public void setItemGuid(String itemGuid) {
        this.itemGuid = itemGuid;
    }

    public String getItemType() {
        return itemType;
    }

    public void setItemType(String itemType) {
        this.itemType = itemType;
    }
}
