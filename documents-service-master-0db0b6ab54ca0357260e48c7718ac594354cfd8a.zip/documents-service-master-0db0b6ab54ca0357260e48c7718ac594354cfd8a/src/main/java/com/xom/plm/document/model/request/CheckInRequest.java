package com.xom.plm.document.model.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.hibernate.validator.constraints.NotBlank;

import javax.validation.constraints.NotNull;

/**
 * Created by tlokeja on 9/15/2017.
 */
public class CheckInRequest {

    @JsonProperty("documentType")
    @NotNull
    @NotBlank
    private String documentType;

    @JsonProperty("documentNumber")
    @NotNull
    @NotBlank
    private String documentNumber;

    @JsonProperty("fileId")
    @NotNull
    @NotBlank
    private String fileId;

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    public String getDocumentNumber() {
        return documentNumber;
    }

    public void setDocumentNumber(String documentNumber) {
        this.documentNumber = documentNumber;
    }

    public String getFileId() {
        return fileId;
    }

    public void setFileId(String fileId) {
        this.fileId = fileId;
    }
}
