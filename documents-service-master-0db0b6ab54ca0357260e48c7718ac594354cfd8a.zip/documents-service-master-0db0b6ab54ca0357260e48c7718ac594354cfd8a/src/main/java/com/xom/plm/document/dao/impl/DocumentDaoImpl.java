package com.xom.plm.document.dao.impl;

import com.xom.plm.document.dao.DocumentDao;
import com.xom.plm.document.model.json.Document;
import com.xom.plm.document.model.request.CreateAndLinkRequest;
import com.xom.plm.document.proxy.HttpAdapter;
import com.xom.plm.document.proxy.SAPAdapter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.util.UriComponentsBuilder;

/**
 * Created by tlokeja on 9/13/2017.
 */
@Repository
public class DocumentDaoImpl implements DocumentDao {

    private final String createAndLinkUrl;
    private final HttpAdapter httpAdapter;
    private final SAPAdapter sapAdapter;

    private final String sapCheckInURL;

    @Autowired
    public DocumentDaoImpl(HttpAdapter httpAdapter,
                           SAPAdapter sapAdapter,
                           @Value("${sap.api.url.document.createAndLink}") String createAndLinkUrl,
                           @Value("${sap.api.url.document.checkin}") String sapCheckInURL) {
        this.httpAdapter = httpAdapter;
        this.sapAdapter = sapAdapter;
        this.createAndLinkUrl = createAndLinkUrl;
        this.sapCheckInURL = sapCheckInURL;
    }

    @Override
    public Document createAndLinkDocument(CreateAndLinkRequest request) throws HttpClientErrorException {

        HttpHeaders headers = sapAdapter.createTokenSAPHeader();

        HttpEntity<CreateAndLinkRequest> entity = new HttpEntity<>(request, headers);

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(this.createAndLinkUrl);

        ResponseEntity<Document> response = (ResponseEntity<Document>) httpAdapter.call(String.valueOf(builder.build().encode().toUri()), HttpMethod.POST,
                entity, Document.class);

        return response.getBody();
    }

    @Override
    public void checkInDocument(String documentType, String documentNumber, String fileId) throws HttpClientErrorException {
        HttpHeaders headers = sapAdapter.createTokenSAPHeader();

        HttpEntity<String> entity = new HttpEntity<>(headers);

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(
                this.sapCheckInURL.replace("{documentType}", documentType)
                        .replace("{documentNumber}", documentNumber).replace("{fileId}", fileId));

        httpAdapter.call(String.valueOf(builder.build().encode().toUri()), HttpMethod.PUT,
                entity, String.class);
    }
}
