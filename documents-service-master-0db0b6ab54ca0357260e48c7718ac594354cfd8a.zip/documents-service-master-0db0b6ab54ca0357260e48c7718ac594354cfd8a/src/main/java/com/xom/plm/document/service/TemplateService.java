package com.xom.plm.document.service;

import com.xom.plm.document.model.json.Document;

import java.util.List;

/**
 * Created by tlokeja on 8/9/2017.
 */
public interface TemplateService {
    List<Document> getDocumentListFromDocumentType(String documentType);
}
