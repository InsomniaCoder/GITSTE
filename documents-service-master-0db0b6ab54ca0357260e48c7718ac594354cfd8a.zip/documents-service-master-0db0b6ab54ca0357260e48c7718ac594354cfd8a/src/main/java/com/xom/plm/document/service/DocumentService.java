package com.xom.plm.document.service;

import com.xom.plm.document.model.json.Document;
import com.xom.plm.document.model.response.GetOriginalResponse;
import org.springframework.web.client.HttpClientErrorException;

/**
 * Created by tlokeja on 8/9/2017.
 */
public interface DocumentService {

    Document createAndLinkDocumentWithObject(String documentType, String documentNumber, String itemGuid) throws HttpClientErrorException;

    GetOriginalResponse getOriginalUrlAndLocalPath(String documentType, String documentNumber) throws HttpClientErrorException;

    void checkInDocument(String documentType, String documentNumber, String fileId);

    GetOriginalResponse createNewOriginalUrl(String documentType, String documentNumber);
}
