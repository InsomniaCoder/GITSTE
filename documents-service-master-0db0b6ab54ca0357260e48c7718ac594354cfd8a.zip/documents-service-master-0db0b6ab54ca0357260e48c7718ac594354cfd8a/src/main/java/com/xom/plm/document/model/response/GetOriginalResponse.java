package com.xom.plm.document.model.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.hibernate.validator.constraints.NotBlank;

import javax.validation.constraints.NotNull;

/**
 * Created by tlokeja on 9/5/2017.
 */
public class GetOriginalResponse {

    @JsonProperty("ORIGINAL_URL")
    @NotNull
    @NotBlank
    private String originalUrl;

    @JsonProperty("LOCAL_PATH")
    @NotNull
    @NotBlank
    private String localPath;

    public GetOriginalResponse() {
    }

    public GetOriginalResponse(String originalUrl, String localPath) {
        this.originalUrl = originalUrl;
        this.localPath = localPath;
    }

    public String getOriginalUrl() {
        return originalUrl;
    }

    public void setOriginalUrl(String originalUrl) {
        this.originalUrl = originalUrl;
    }

    public String getLocalPath() {
        return localPath;
    }

    public void setLocalPath(String localPath) {
        this.localPath = localPath;
    }
}
