package com.xom.plm.document.service.implementation;

import com.xom.plm.document.dao.DMSDao;
import com.xom.plm.document.dao.DocumentDao;
import com.xom.plm.document.model.json.Document;
import com.xom.plm.document.model.request.CreateAndLinkRequest;
import com.xom.plm.document.model.request.DocumentTemplate;
import com.xom.plm.document.model.response.GetOriginalResponse;
import com.xom.plm.document.service.DocumentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;

/**
 * Created by tlokeja on 8/2/2017.
 */
@Service
public class DocumentServiceImpl implements DocumentService {

    private final DocumentDao documentDao;
    private final DMSDao dmsDao;

    @Autowired
    public DocumentServiceImpl(DocumentDao documentDao, DMSDao dmsDao) {
        this.documentDao = documentDao;
        this.dmsDao = dmsDao;
    }

    @Override
    public Document createAndLinkDocumentWithObject(String documentType, String documentNumber, String itemGuid) throws HttpClientErrorException {
        CreateAndLinkRequest requestBody = new CreateAndLinkRequest(new DocumentTemplate(documentType, documentNumber), itemGuid);
        return documentDao.createAndLinkDocument(requestBody);
    }

    @Override
    public GetOriginalResponse getOriginalUrlAndLocalPath(String documentType, String documentNumber) throws HttpClientErrorException {
        return dmsDao.getOriginalUrlAndLocalPath(documentType, documentNumber);
    }

    @Override
    public void checkInDocument(String documentType, String documentNumber, String fileId) throws HttpClientErrorException {
        documentDao.checkInDocument(documentType, documentNumber, fileId);
    }

    @Override
    public GetOriginalResponse createNewOriginalUrl(String documentType, String documentNumber) {
        return dmsDao.createNewOriginalUrl(documentType, documentNumber);
    }
}