package com.xom.plm.document.controller;

import com.xom.plm.document.model.json.Document;
import com.xom.plm.document.model.request.CreateDocumentsRequest;
import com.xom.plm.document.model.response.GetOriginalResponse;
import com.xom.plm.document.service.DocumentService;
import com.xom.plm.document.service.TemplateService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by tlokeja on 7/31/2017.
 */
@RestController
public class DocumentController {

    private final DocumentService documentService;
    private final TemplateService templateService;

    private final Logger log = LoggerFactory.getLogger(this.getClass());

    @Autowired
    public DocumentController(DocumentService documentService, TemplateService templateService) {
        this.documentService = documentService;
        this.templateService = templateService;
    }

    @GetMapping("/")
    ResponseEntity<String> hello() {
        return new ResponseEntity<>("Document controller hello!", HttpStatus.OK);
    }

    /**
     * @param createRequestBody contains item_guid and item_type :item_type example is like Z001
     * @return list of generated document from SAP
     */
    @PostMapping(value = "/pmoc/documents", consumes = "application/json", produces = "application/json")
    ResponseEntity<List<Document>> createDocumentsFromTemplate(@Valid @RequestBody CreateDocumentsRequest createRequestBody) {

        log.info("link document for " + createRequestBody.getItemGuid() + " by type " + createRequestBody.getItemType());

        List<Document> documentTemplates = templateService.getDocumentListFromDocumentType(createRequestBody.getItemType());

        log.info("template size is : " + documentTemplates.size());

        List<Document> createdDocumentList = new ArrayList<>();

        documentTemplates.forEach(document -> createdDocumentList.add(documentService.createAndLinkDocumentWithObject(document.getDocumentType(),
                document.getDocumentNumber(), createRequestBody.getItemGuid())));

        return new ResponseEntity<>(createdDocumentList, HttpStatus.CREATED);
    }

    @GetMapping(value = "/pmoc/documents/original", produces = "application/json")
    ResponseEntity<GetOriginalResponse> getOriginalFileUrlAndLocation(@RequestParam String documentType, @RequestParam String documentNumber) {

        log.info("retrieve url and location of type " + documentType + " number " + documentNumber);

        return new ResponseEntity<>(documentService.getOriginalUrlAndLocalPath(documentType, documentNumber), HttpStatus.OK);
    }

    @PostMapping(value = "/pmoc/documents/original/{documentType}/{documentNumber}/000/00", produces = "application/json")
    ResponseEntity<GetOriginalResponse> createNewOriginalUrl(@PathVariable String documentType, @PathVariable String documentNumber) {

        GetOriginalResponse getOriginalResponse =
                documentService.createNewOriginalUrl(documentType, documentNumber);

        return new ResponseEntity<>(getOriginalResponse, HttpStatus.CREATED);
    }

    @PostMapping(value = "/pmoc/documents/checkin/{fileId}/{documentType}/{documentNumber}", produces = "application/json")
    ResponseEntity<HttpStatus> checkInDocument(@PathVariable String fileId, @PathVariable String documentType, @PathVariable String documentNumber) {

        documentService.checkInDocument(documentType, documentNumber, fileId);

        return new ResponseEntity<>(HttpStatus.OK);
    }
}