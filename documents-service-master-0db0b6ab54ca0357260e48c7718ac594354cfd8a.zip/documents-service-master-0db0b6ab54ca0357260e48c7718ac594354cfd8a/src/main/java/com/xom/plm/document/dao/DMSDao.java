package com.xom.plm.document.dao;

import com.xom.plm.document.model.response.GetOriginalResponse;
import org.springframework.web.client.HttpClientErrorException;

/**
 * Created by tlokeja on 9/13/2017.
 */
public interface DMSDao {
    GetOriginalResponse getOriginalUrlAndLocalPath(String documentType, String documentNumber) throws HttpClientErrorException;

    GetOriginalResponse createNewOriginalUrl(String documentType, String documentNumber) throws HttpClientErrorException;
}
