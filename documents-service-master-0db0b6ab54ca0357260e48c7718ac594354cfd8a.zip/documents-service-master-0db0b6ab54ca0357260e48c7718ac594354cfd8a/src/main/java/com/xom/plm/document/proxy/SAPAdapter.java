package com.xom.plm.document.proxy;

import org.springframework.http.HttpHeaders;

/**
 * Created by tlokeja on 8/10/2017.
 */
public interface SAPAdapter {
    HttpHeaders createBasicSAPHeader();

    HttpHeaders createTokenSAPHeader();
}
