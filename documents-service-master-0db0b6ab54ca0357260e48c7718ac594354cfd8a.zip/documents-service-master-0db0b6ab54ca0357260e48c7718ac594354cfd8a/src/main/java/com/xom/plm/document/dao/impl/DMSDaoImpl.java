package com.xom.plm.document.dao.impl;

import com.xom.plm.document.dao.DMSDao;
import com.xom.plm.document.model.response.GetOriginalResponse;
import com.xom.plm.document.proxy.HttpAdapter;
import com.xom.plm.document.proxy.SAPAdapter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.util.UriComponentsBuilder;

/**
 * Created by tlokeja on 9/13/2017.
 */
@Repository
public class DMSDaoImpl implements DMSDao {

    private final HttpAdapter httpAdapter;
    private final SAPAdapter sapAdapter;

    private final String sapGetOriginalURL;
    private final String sapCreateNewOriginalURL;


    private final Logger log = LoggerFactory.getLogger(this.getClass());

    @Autowired
    public DMSDaoImpl(HttpAdapter httpAdapter,
                      SAPAdapter sapAdapter,
                      @Value("${sap.api.url.document.getOriginalUrlAndLocalPath}") String sapGetOriginalURL,
                      @Value("${sap.api.url.document.createNewOriginalUrl}") String sapCreateNewOriginalURL) {
        this.httpAdapter = httpAdapter;
        this.sapAdapter = sapAdapter;
        this.sapGetOriginalURL = sapGetOriginalURL;
        this.sapCreateNewOriginalURL = sapCreateNewOriginalURL;
    }

    @Override
    public GetOriginalResponse getOriginalUrlAndLocalPath(String documentType, String documentNumber) throws HttpClientErrorException {

        HttpHeaders headers = sapAdapter.createTokenSAPHeader();

        HttpEntity<String> entity = new HttpEntity<>(headers);//fix something

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(this.sapGetOriginalURL.replace("{documentType}", documentType)
                .replace("{documentNumber}", documentNumber));


        ResponseEntity<GetOriginalResponse> response = (ResponseEntity<GetOriginalResponse>) httpAdapter.call(String.valueOf(builder.build().encode().toUri()), HttpMethod.GET,
                entity, GetOriginalResponse.class);

        return response.getBody();
    }

    @Override
    public GetOriginalResponse createNewOriginalUrl(String documentType, String documentNumber) throws HttpClientErrorException {
        HttpHeaders headers = sapAdapter.createTokenSAPHeader();

        HttpEntity<String> entity = new HttpEntity<>(headers);

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(this.sapCreateNewOriginalURL.replace("{documentType}", documentType)
                .replace("{documentNumber}", documentNumber));

        ResponseEntity<GetOriginalResponse> response = (ResponseEntity<GetOriginalResponse>) httpAdapter.call(String.valueOf(builder.build().encode().toUri()), HttpMethod.POST,
                entity, GetOriginalResponse.class);

        return response.getBody();
    }
}
