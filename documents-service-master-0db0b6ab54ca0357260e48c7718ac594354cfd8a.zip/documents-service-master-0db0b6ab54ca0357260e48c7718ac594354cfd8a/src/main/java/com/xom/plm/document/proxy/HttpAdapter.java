package com.xom.plm.document.proxy;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;

/**
 * Created by tlokeja on 8/9/2017.
 */
public interface HttpAdapter {
    ResponseEntity<?> call(String url, HttpMethod method, HttpEntity entity, Class classes);
}
