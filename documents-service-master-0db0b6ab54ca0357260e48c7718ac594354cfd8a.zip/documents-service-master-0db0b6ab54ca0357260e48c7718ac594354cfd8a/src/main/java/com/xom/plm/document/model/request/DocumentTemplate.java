package com.xom.plm.document.model.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.hibernate.validator.constraints.NotBlank;

import javax.validation.constraints.NotNull;

/**
 * Created by tlokeja on 9/12/2017.
 */
public class DocumentTemplate {

    @JsonProperty("documenttype")
    @NotNull
    @NotBlank
    private String documentType;

    @JsonProperty("documentnumber")
    @NotNull
    @NotBlank
    private String documentNumber;

    public DocumentTemplate() {
    }

    public DocumentTemplate(String documentType, String documentNumber) {
        this.documentType = documentType;
        this.documentNumber = documentNumber;
    }

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    public String getDocumentNumber() {
        return documentNumber;
    }

    public void setDocumentNumber(String documentNumber) {
        this.documentNumber = documentNumber;
    }
}
