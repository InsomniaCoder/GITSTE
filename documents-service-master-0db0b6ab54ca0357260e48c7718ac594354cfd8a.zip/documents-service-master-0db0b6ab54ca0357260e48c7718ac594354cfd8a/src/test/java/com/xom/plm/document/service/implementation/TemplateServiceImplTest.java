package com.xom.plm.document.service.implementation;

import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.xom.plm.document.model.json.Document;
import com.xom.plm.document.service.TemplateService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;

/**
 * Created by tlokeja on 8/7/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class TemplateServiceImplTest {


    private TemplateService templateService;

    @Before
    public void setUp() throws Exception {

        ObjectMapper jsonMapper = new ObjectMapper();
        jsonMapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);

        this.templateService = new TemplateServiceImpl("YPMOC_DIR_TEMPLT_TEST.json", jsonMapper);
    }

    @Test
    public void getMultipleDocTemplateShouldReturnCorrectList() throws Exception {

        List<Document> foundDocument = this.templateService.getDocumentListFromDocumentType("Z001");
        assertEquals(3, foundDocument.size());

        Document firstDoc = foundDocument.get(0);
        assertEquals("0000000020000000000000000", firstDoc.getDocumentNumber());
        assertEquals("ZPF", firstDoc.getDocumentType());
        assertEquals("000", firstDoc.getDocumentPart());
        assertEquals("00", firstDoc.getDocumentVersion());

        Document secondDoc = foundDocument.get(1);
        assertEquals("0000000020000000000000003", secondDoc.getDocumentNumber());
        assertEquals("ZPF", secondDoc.getDocumentType());
        assertEquals("000", secondDoc.getDocumentPart());
        assertEquals("00", secondDoc.getDocumentVersion());

        Document thirdDoc = foundDocument.get(2);
        assertEquals("0000000020000000000000004", thirdDoc.getDocumentNumber());
        assertEquals("ZPF", thirdDoc.getDocumentType());
        assertEquals("000", thirdDoc.getDocumentPart());
        assertEquals("00", thirdDoc.getDocumentVersion());
    }

    @Test
    public void getSingleDocTemplateShouldReturnCorrectList() throws Exception {

        List<Document> foundDocument = this.templateService.getDocumentListFromDocumentType("Z006");
        assertEquals(1, foundDocument.size());

        Document doc = foundDocument.get(0);
        assertEquals("0000000020000000000000001", doc.getDocumentNumber());
        assertEquals("ZPF", doc.getDocumentType());
        assertEquals("000", doc.getDocumentPart());
        assertEquals("00", doc.getDocumentVersion());
    }

    @Test
    public void getTemplateWithFalseTypeShouldThrowTemplateNotFound() throws Exception {
        List<Document> foundDocument = this.templateService.getDocumentListFromDocumentType("not_exist_template_type");
        assertEquals(new ArrayList<>().size(), foundDocument.size());
    }
}