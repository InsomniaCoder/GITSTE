package com.xom.plm.document.proxy.implementation;

import com.xom.plm.document.proxy.HttpAdapter;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.*;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;

/**
 * Created by tlokeja on 8/10/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class SAPAdapterImplTest {

    private SAPAdapterImpl sapAdapter;

    @Mock
    private HttpAdapter mockHttpAdapter;

    private final String encodedRestServiceId = "testBasicRestId";
    private final String sapGetXCSRFTokenRestURL = "http://mockurl/testxcsfrrestURL";
    private static final String X_CSRF_TOKEN = "X-CSRF-Token";
    private static final String ACCEPT = "Accept";
    private static final String AUTHORIZATION = "Authorization";

    @Before
    public void setUp() throws Exception {
        sapAdapter = new SAPAdapterImpl(mockHttpAdapter, encodedRestServiceId, sapGetXCSRFTokenRestURL);
    }

    @Test
    public void createBasicSAPHeaderTest() {
        HttpHeaders expectedBasicSAPHeader = new HttpHeaders();
        expectedBasicSAPHeader.add(ACCEPT, MediaType.APPLICATION_JSON_VALUE);
        expectedBasicSAPHeader.add(AUTHORIZATION, "Basic " + this.encodedRestServiceId);

        HttpHeaders actualHeaderReturned = sapAdapter.createBasicSAPHeader();

        assertEquals(expectedBasicSAPHeader.getFirst(ACCEPT), actualHeaderReturned.getFirst(ACCEPT));
        assertEquals(expectedBasicSAPHeader.getFirst(AUTHORIZATION), actualHeaderReturned.getFirst(AUTHORIZATION));
    }

    @Test
    public void createTokenSAPHeader() {
        HttpHeaders expectedTokenSAPHeader = new HttpHeaders();
        expectedTokenSAPHeader.add(ACCEPT, MediaType.APPLICATION_JSON_VALUE);
        expectedTokenSAPHeader.add(AUTHORIZATION, "Basic " + this.encodedRestServiceId);

        String mockReturned_XCSFR_token = "MockReturned_XSRF_Token";

        expectedTokenSAPHeader.add(X_CSRF_TOKEN, mockReturned_XCSFR_token);

        ResponseEntity<String> mockHttpResponse = new ResponseEntity<>("", expectedTokenSAPHeader, HttpStatus.OK);

        doReturn(mockHttpResponse).when(mockHttpAdapter).call(eq(sapGetXCSRFTokenRestURL), eq(HttpMethod.GET), any(), eq(String.class));

        HttpHeaders actualHeaderReturned = sapAdapter.createTokenSAPHeader();

        verify(mockHttpAdapter, times(1)).call(eq(sapGetXCSRFTokenRestURL), eq(HttpMethod.GET), any(), eq(String.class));

        assertEquals(expectedTokenSAPHeader.getFirst(ACCEPT), actualHeaderReturned.getFirst(ACCEPT));
        assertEquals(expectedTokenSAPHeader.getFirst(AUTHORIZATION), actualHeaderReturned.getFirst(AUTHORIZATION));
        assertEquals(expectedTokenSAPHeader.getFirst(X_CSRF_TOKEN), actualHeaderReturned.getFirst(X_CSRF_TOKEN));
    }


}