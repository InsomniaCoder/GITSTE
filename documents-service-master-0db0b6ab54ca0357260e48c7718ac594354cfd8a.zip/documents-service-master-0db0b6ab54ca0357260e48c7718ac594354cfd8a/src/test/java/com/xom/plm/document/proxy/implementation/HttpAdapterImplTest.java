package com.xom.plm.document.proxy.implementation;

import com.xom.plm.document.proxy.HttpAdapter;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;

/**
 * Created by tlokeja on 8/10/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class HttpAdapterImplTest {

    private HttpAdapter httpAdapter;

    @Mock
    private RestTemplate mockRestTemplate;

    @Before
    public void setUp() throws Exception {
        this.httpAdapter = new HttpAdapterImpl(mockRestTemplate);
    }

    @Test
    public void call() throws Exception {

        when(mockRestTemplate.exchange(anyString(), eq(HttpMethod.GET), any(), eq(String.class))).thenReturn(new ResponseEntity<>("successful", HttpStatus.OK));

        ResponseEntity<String> mockURL = (ResponseEntity<String>) this.httpAdapter.call("mockURL", HttpMethod.GET, new HttpEntity(new HttpHeaders()), String.class);

        verify(mockRestTemplate, times(1)).exchange(anyString(), eq(HttpMethod.GET), any(), eq(String.class));

        assertEquals(HttpStatus.OK, mockURL.getStatusCode());
        assertEquals("successful", mockURL.getBody());
    }
}