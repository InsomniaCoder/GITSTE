package com.xom.plm.document.service.implementation;

import com.xom.plm.document.dao.DMSDao;
import com.xom.plm.document.dao.DocumentDao;
import com.xom.plm.document.model.json.Document;
import com.xom.plm.document.model.request.CreateAndLinkRequest;
import com.xom.plm.document.model.request.DocumentTemplate;
import com.xom.plm.document.model.response.GetOriginalResponse;
import com.xom.plm.document.service.DocumentService;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.web.client.HttpClientErrorException;

import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;

/**
 * Created by tlokeja on 8/9/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class DocumentServiceImplTest {

    private DocumentService documentService;

    @Mock
    private DocumentDao mockDocumentDao;

    @Mock
    private DMSDao mockDmsDao;

    @Before
    public void setUp() throws Exception {
        documentService = new DocumentServiceImpl(mockDocumentDao, mockDmsDao);
    }

    @Test
    public void createAndLinkNormalTest() {

        String expectedDocType = "TestType1";
        String expectedDocNumber = "New1";
        Document expectedResponse = new Document(expectedDocType, expectedDocNumber);

        CreateAndLinkRequest mockRequest = new CreateAndLinkRequest(new DocumentTemplate(expectedDocType, expectedDocNumber),
                "Test_GUID");

        when(mockDocumentDao.createAndLinkDocument((CreateAndLinkRequest) notNull()))
                .thenReturn(new Document("TestType1", "New1"));

        Document actualResponse = documentService.createAndLinkDocumentWithObject("TestType1", "New1", "Test_GUID");

        verify(mockDocumentDao, times(1)).createAndLinkDocument(any());

        ArgumentCaptor<CreateAndLinkRequest> argument = ArgumentCaptor.forClass(CreateAndLinkRequest.class);
        verify(mockDocumentDao).createAndLinkDocument(argument.capture());
        Assert.assertEquals(mockRequest.getObjectGuid(), argument.getValue().getObjectGuid());
        Assert.assertEquals(mockRequest.getTemplate().getDocumentType(), argument.getValue().getTemplate().getDocumentType());
        Assert.assertEquals(mockRequest.getTemplate().getDocumentNumber(), argument.getValue().getTemplate().getDocumentNumber());

        Assert.assertNotNull(actualResponse);
        Assert.assertEquals(expectedResponse.getDocumentType(), actualResponse.getDocumentType());
        Assert.assertEquals(expectedResponse.getDocumentNumber(), actualResponse.getDocumentNumber());
    }

    @Test(expected = HttpClientErrorException.class)
    public void createAndLinkNormalTestFailShouldThrowException() throws Exception {

        doThrow(HttpClientErrorException.class).when(mockDocumentDao).createAndLinkDocument(any());

        documentService.createAndLinkDocumentWithObject("FailType", "xxxxx", "xxxxxx");
    }

    @Test
    public void getOriginalUrlAndLocalPathNormalTest() {

        String expectedUrl = "http://expectedUrl";
        String expectedPath = "c:\\testpath";

        when(mockDmsDao.getOriginalUrlAndLocalPath("TestType", "TestNumber")).
                thenReturn(new GetOriginalResponse(expectedUrl, expectedPath));

        GetOriginalResponse actualResponse = documentService.getOriginalUrlAndLocalPath("TestType", "TestNumber");


        verify(mockDmsDao, times(1)).getOriginalUrlAndLocalPath(anyString(), anyString());

        Assert.assertNotNull(actualResponse);
        Assert.assertEquals(expectedUrl, actualResponse.getOriginalUrl());
        Assert.assertEquals(expectedPath, actualResponse.getLocalPath());
    }

    @Test(expected = HttpClientErrorException.class)
    public void getOriginalUrlAndLocalPathNormalTestFailShouldThrowException() throws Exception {

        doThrow(HttpClientErrorException.class).when(mockDmsDao).getOriginalUrlAndLocalPath(anyString(), anyString());
        documentService.getOriginalUrlAndLocalPath("Fail", "Fail");
    }

    @Test
    public void checkInDocumentTest() {

        String mockDocumentType = "ZXXX";
        String mockDocumentNumber = "2000XXX";
        String mockDocumentFileId = "10BVS_TEST";

        doNothing().when(mockDocumentDao).checkInDocument(eq(mockDocumentType), eq(mockDocumentNumber), eq(mockDocumentFileId));

        documentService.checkInDocument(mockDocumentType, mockDocumentNumber, mockDocumentFileId);

        verify(mockDocumentDao, times(1)).checkInDocument(eq(mockDocumentType), eq(mockDocumentNumber), eq(mockDocumentFileId));
    }

    @Test(expected = HttpClientErrorException.class)
    public void checkInDocumentTestTestFailShouldThrowException() throws Exception {

        String mockDocumentType = "ZXXX";
        String mockDocumentNumber = "2000XXX";
        String mockDocumentFileId = "10BVS_TEST";

        doThrow(HttpClientErrorException.class).when(mockDocumentDao).checkInDocument(eq(mockDocumentType), eq(mockDocumentNumber), eq(mockDocumentFileId));

        documentService.checkInDocument(mockDocumentType, mockDocumentNumber, mockDocumentFileId);
    }

    @Test
    public void createNewOriginalUrlTest() {

        String expectedUrl = "http://newlyCreatedUrl";
        String expectedPath = "C:\\SAP\\Local";

        when(mockDmsDao.createNewOriginalUrl("ZXXX", "2000XXX")).
                thenReturn(new GetOriginalResponse(expectedUrl, expectedPath));

        GetOriginalResponse actualResponse = documentService.createNewOriginalUrl("ZXXX", "2000XXX");

        verify(mockDmsDao, times(1)).createNewOriginalUrl(eq("ZXXX"), eq("2000XXX"));

        Assert.assertNotNull(actualResponse);
        Assert.assertEquals(expectedUrl, actualResponse.getOriginalUrl());
        Assert.assertEquals(expectedPath, actualResponse.getLocalPath());
    }

    @Test(expected = HttpClientErrorException.class)
    public void createNewOriginalUrlTestFailShouldThrowException() throws Exception {

        doThrow(HttpClientErrorException.class).when(mockDmsDao).createNewOriginalUrl(anyString(), anyString());
        documentService.createNewOriginalUrl("Fail", "Fail");
    }


}