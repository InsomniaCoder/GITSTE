package com.xom.plm.document.controller;

import com.xom.plm.document.WebSecurityConfig;
import com.xom.plm.document.model.json.Document;
import com.xom.plm.document.model.response.GetOriginalResponse;
import com.xom.plm.document.service.DocumentService;
import com.xom.plm.document.service.TemplateService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.client.HttpClientErrorException;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.core.Is.is;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Created by tlokeja on 8/1/2017.
 */
@RunWith(SpringRunner.class)
@Import(WebSecurityConfig.class)
@WebMvcTest(DocumentController.class)
public class DocumentControllerTest {


    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private DocumentService documentService;

    @MockBean
    private TemplateService templateService;

    @Before
    public void setUp() {
    }

    @Test
    public void callRootEndpointWithoutUserShouldPass() throws Exception {
        mockMvc.perform(get("/")
        ).andExpect(status().isOk()).andExpect(content().string("Document controller hello!"));
    }

    @Test
    @WithMockUser()
    public void createDocumentsFromTemplateTest() throws Exception {

        List<Document> mockDocuments = new ArrayList<>();
        mockDocuments.add(new Document("Z001TEST", "test1"));
        mockDocuments.add(new Document("Z001TEST", "test2"));
        when(templateService.getDocumentListFromDocumentType("Z001TEST")).thenReturn(mockDocuments);

        when(documentService.createAndLinkDocumentWithObject("Z001TEST", "test1", "005056AA1B411ED79DEAA08AD5E440D1"))
                .thenReturn(new Document("Z001TEST", "NEW1"));
        when(documentService.createAndLinkDocumentWithObject("Z001TEST", "test2", "005056AA1B411ED79DEAA08AD5E440D1"))
                .thenReturn(new Document("Z001TEST", "NEW2"));

        String mockCreateDocRequest = "{\"ITEM_GUID\":\"005056AA1B411ED79DEAA08AD5E440D1\"," +
                " \"ITEM_TYPE\":\"Z001TEST\"}";
        mockMvc.perform(post("/pmoc/documents").contentType("application/json").content(mockCreateDocRequest)
        ).andExpect(status().isCreated())
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0].DOCUMENTTYPE", is("Z001TEST")))
                .andExpect(jsonPath("$[0].DOCUMENTNUMBER", is("NEW1")))
                .andExpect(jsonPath("$[1].DOCUMENTTYPE", is("Z001TEST")))
                .andExpect(jsonPath("$[1].DOCUMENTNUMBER", is("NEW2")));
    }

    @Test
    @WithMockUser()
    public void createDocumentsFromTemplateParameterInvalidShouldReturnBadRequest() throws Exception {

        String mockCreateDocRequest = "{\"wrongKey1\":\"005056AA1B411ED79DEAA08AD5E440D1\"," +
                " \"item_TyPez\":\"Z001TEST\"}";

        mockMvc.perform(post("/pmoc/documents").contentType("application/json").content(mockCreateDocRequest)
        ).andExpect(status().isBadRequest());

    }

    @Test
    @WithMockUser()
    public void createDocumentsFromTemplateInterfaceErrorShouldReturnINTERNAL_SERVER_ERROR() throws Exception {

        List<Document> mockDocuments = new ArrayList<>();
        mockDocuments.add(new Document("Z001TEST", "test1"));
        mockDocuments.add(new Document("Z001TEST", "test2"));
        when(templateService.getDocumentListFromDocumentType("Z001TEST")).thenReturn(mockDocuments);

        doThrow(HttpClientErrorException.class).when(documentService).createAndLinkDocumentWithObject(any(), any(), any());

        String mockCreateDocRequest = "{\"ITEM_GUID\":\"005056AA1B411ED79DEAA08AD5E440D1\"," +
                " \"ITEM_TYPE\":\"Z001TEST\"}";

        mockMvc.perform(post("/pmoc/documents").contentType("application/json").content(mockCreateDocRequest)
        ).andExpect(status().isInternalServerError());
    }

    @Test
    @WithMockUser()
    public void createDocumentsFromTemplateAnyErrorShouldReturnINTERNAL_SERVER_ERROR() throws Exception {

        List<Document> mockDocuments = new ArrayList<>();
        mockDocuments.add(new Document("Z001TEST", "test1"));
        mockDocuments.add(new Document("Z001TEST", "test2"));
        when(templateService.getDocumentListFromDocumentType("Z001TEST")).thenReturn(mockDocuments);
        doThrow(Exception.class).when(documentService).createAndLinkDocumentWithObject(any(), any(), any());

        String mockCreateDocRequest = "{\"ITEM_GUID\":\"005056AA1B411ED79DEAA08AD5E440D1\"," +
                " \"ITEM_TYPE\":\"Z001TEST\"}";
        mockMvc.perform(post("/pmoc/documents").contentType("application/json").content(mockCreateDocRequest)
        ).andExpect(status().isInternalServerError());
    }

    @Test
    @WithMockUser()
    public void getDocumentOriginalUrlAndLocalPath() throws Exception {

        GetOriginalResponse mockResponse = new GetOriginalResponse("http://testUrl", "C:\\localPath");
        when(documentService.getOriginalUrlAndLocalPath("ZPP", "testnumber"))
                .thenReturn(mockResponse);

        mockMvc.perform(get("/pmoc/documents/original")
                .param("documentType", "ZPP")
                .param("documentNumber", "testnumber")
                .contentType("application/json")
        ).andExpect(status().isOk())
                .andExpect(jsonPath("$.ORIGINAL_URL", is("http://testUrl")))
                .andExpect(jsonPath("$.LOCAL_PATH", is("C:\\localPath")));
    }

    @Test
    @WithMockUser()
    public void getDocumentOriginalUrlAndLocalPathThrowClassCast() throws Exception {

        doThrow(ClassCastException.class).when(documentService).getOriginalUrlAndLocalPath(anyString(), anyString());

        mockMvc.perform(get("/pmoc/documents/original")
                .param("documentType", "ZPP")
                .param("documentNumber", "testnumber")
                .contentType("application/json")
        ).andExpect(status().isInternalServerError());
    }

    @Test
    @WithMockUser()
    public void getDocumentOriginalUrlAndLocalPathInterfaceErrorShouldReturnINTERNAL_SERVER_ERROR() throws Exception {

        doThrow(HttpClientErrorException.class).when(documentService).getOriginalUrlAndLocalPath(anyString(), anyString());

        mockMvc.perform(get("/pmoc/documents/original")
                .param("documentType", "ZPP")
                .param("documentNumber", "testnumber")
                .contentType("application/json")
        ).andExpect(status().isInternalServerError());
    }

    @Test
    @WithMockUser()
    public void getDocumentOriginalUrlAndLocalPathAnyErrorShouldReturnINTERNAL_SERVER_ERROR() throws Exception {

        doThrow(Exception.class).when(documentService).getOriginalUrlAndLocalPath(anyString(), anyString());

        mockMvc.perform(get("/pmoc/documents/original")
                .param("documentType", "ZPP")
                .param("documentNumber", "testnumber")
                .contentType("application/json")
        ).andExpect(status().isInternalServerError());
    }

    @Test
    @WithMockUser()
    public void createNewOriginalShouldReturnValidResponse() throws Exception {

        GetOriginalResponse mockExpectedResponse = new GetOriginalResponse("http://newUrl", "C:\\ProgramData\\SAP\\NWBC");
        when(documentService.createNewOriginalUrl("ZPP", "2000XXX"))
                .thenReturn(mockExpectedResponse);

        mockMvc.perform(post("/pmoc/documents/original/ZPP/2000XXX/000/00").contentType("application/json")
        ).andExpect(status().isCreated())
                .andExpect(jsonPath("$.ORIGINAL_URL", is("http://newUrl")))
                .andExpect(jsonPath("$.LOCAL_PATH", is("C:\\ProgramData\\SAP\\NWBC")));
    }


    @Test
    @WithMockUser()
    public void createNewOriginalLackParameterShouldReturnNotFound() throws Exception {


        mockMvc.perform(post("/pmoc/documents/original/ZPP/2000XXX").contentType("application/json")
        ).andExpect(status().isNotFound());
    }

    @Test
    @WithMockUser()
    public void createNewOriginalInterfaceFailShouldReturnINTERNAL_SERVER_ERROR() throws Exception {

        doThrow(HttpClientErrorException.class).when(documentService).createNewOriginalUrl(anyString(), anyString());

        mockMvc.perform(post("/pmoc/documents/original/ZPP/2000XXX/000/00").contentType("application/json")
        ).andExpect(status().isInternalServerError());
    }


    @Test
    @WithMockUser()
    public void createNewOriginalFailShouldReturnINTERNAL_SERVER_ERROR() throws Exception {

        doThrow(Exception.class).when(documentService).createNewOriginalUrl(anyString(), anyString());

        mockMvc.perform(post("/pmoc/documents/original/ZPP/2000XXX/000/00").contentType("application/json")
        ).andExpect(status().isInternalServerError());
    }

    @Test
    @WithMockUser()
    public void checkInDocumentShouldReturnOK() throws Exception {

        doNothing().when(documentService).checkInDocument(eq("ZXX"), eq("200XXX"), eq("fileId"));
        mockMvc.perform(post("/pmoc/documents/checkin/005056AA1_NEW_ID_FROM_APPLET_UPLOAD/ZXX/200XXX")).andExpect(status().isOk());
    }

    @Test
    @WithMockUser()
    public void checkInDocumentInterfaceFailShouldReturnINTERNAL_SERVER_ERROR() throws Exception {

        doThrow(HttpClientErrorException.class).when(documentService).checkInDocument(eq("ZXX"), eq("200XXX"), eq("005056AA1_NEW_ID_FROM_APPLET_UPLOAD"));
        mockMvc.perform(post("/pmoc/documents/checkin/005056AA1_NEW_ID_FROM_APPLET_UPLOAD/ZXX/200XXX")).andExpect(status().isInternalServerError());
    }

}