package com.xom.plm.document.dao.impl;

import com.xom.plm.document.dao.DMSDao;
import com.xom.plm.document.model.response.GetOriginalResponse;
import com.xom.plm.document.proxy.HttpAdapter;
import com.xom.plm.document.proxy.SAPAdapter;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.util.UriComponentsBuilder;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;

/**
 * Created by tlokeja on 9/13/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class DMSDaoTest {

    private DMSDao dmsDao;

    @Mock
    private HttpAdapter mockHttpAdapter;

    @Mock
    private SAPAdapter mockSapAdapter;

    private final String TEST_GET_ORIGINAL_URL = "https://sapurl//xom/dms/original/{documentType}/{documentNumber}";
    private final String TEST_CREATE_ORIGINAL_URL = "https://sapurl/xom/dms/original/{documentType}/{documentNumber}";


    @Before
    public void setUp() throws Exception {
        dmsDao = new DMSDaoImpl(mockHttpAdapter, mockSapAdapter, TEST_GET_ORIGINAL_URL, TEST_CREATE_ORIGINAL_URL);
    }

    @Test
    public void getOriginalUrlAndLocalPathTest() throws Exception {

        String mockDocumentType = "mockDocumentType";
        String mockDocumentNumber = "mockDocumentNumber";

        String expectedOriginalUrl = "http://fromSAPUrl";
        String expectedLocalPath = "C:\\Test";

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(TEST_GET_ORIGINAL_URL.replace("{documentType}", mockDocumentType)
                .replace("{documentNumber}", mockDocumentNumber));

        GetOriginalResponse expectedResponse = new GetOriginalResponse(expectedOriginalUrl, expectedLocalPath);

        ResponseEntity<GetOriginalResponse> mockResponse =
                new ResponseEntity<>(expectedResponse, new HttpHeaders(), HttpStatus.OK);

        doReturn(mockResponse).when(mockHttpAdapter).call(eq(String.valueOf(builder.build().encode().toUri())), eq(HttpMethod.GET), any(), eq(GetOriginalResponse.class));

        GetOriginalResponse actualResponse = dmsDao.getOriginalUrlAndLocalPath(mockDocumentType, mockDocumentNumber);

        verify(mockSapAdapter, times(1)).createTokenSAPHeader();
        verify(mockHttpAdapter, times(1)).call(anyString(), eq(HttpMethod.GET), any(), eq(GetOriginalResponse.class));

        assertEquals(expectedResponse.getOriginalUrl(), actualResponse.getOriginalUrl());
        assertEquals(expectedResponse.getLocalPath(), actualResponse.getLocalPath());
    }

    @Test(expected = ClassCastException.class)
    public void getOriginalUrlAndLocalPathShouldThrowClassCastWhenBodyIsNotCorrect() throws Exception {


        String invalidJsonBody = "xxx some inconvertible string xxx";
        doReturn(new ResponseEntity<>(invalidJsonBody, new HttpHeaders(), HttpStatus.OK))
                .when(mockHttpAdapter).call(anyString(), any(), any(), any());

        dmsDao.getOriginalUrlAndLocalPath("TESTDOCTYPE", "TESTDOCNUM");
    }

    @Test(expected = HttpClientErrorException.class)
    public void getOriginalUrlAndLocalPathShouldThrowHttpWhenStatusIsNot2xx() throws Exception {

        doThrow(HttpClientErrorException.class).when(mockHttpAdapter).call(any(), any(), any(), any());

        dmsDao.getOriginalUrlAndLocalPath("TESTDOCTYPE", "TESTDOCNUM");
    }

    @Test
    public void createNewOriginalURLTest() throws Exception {

        String mockDocumentType = "ZXXX";
        String mockDocumentNumber = "2000XXX";

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(TEST_CREATE_ORIGINAL_URL
                .replace("{documentType}", mockDocumentType)
                .replace("{documentNumber}", mockDocumentNumber));


        String expectedOriginalUrl = "http://createdOriginalUrl";
        String expectedLocalPath = "C:\\SAP\\LocalPath";

        GetOriginalResponse expectedResponseBody = new GetOriginalResponse(expectedOriginalUrl, expectedLocalPath);

        ResponseEntity<GetOriginalResponse> expectedResponse =
                new ResponseEntity<>(expectedResponseBody, new HttpHeaders(), HttpStatus.OK);

        doReturn(expectedResponse).when(mockHttpAdapter).call(eq(String.valueOf(builder.build().encode().toUri())), eq(HttpMethod.POST), any(), eq(GetOriginalResponse.class));

        GetOriginalResponse actualResponse = dmsDao.createNewOriginalUrl(mockDocumentType, mockDocumentNumber);

        verify(mockSapAdapter, times(1)).createTokenSAPHeader();
        verify(mockHttpAdapter, times(1)).call(eq(String.valueOf(builder.build().encode().toUri())), eq(HttpMethod.POST), any(), eq(GetOriginalResponse.class));

        assertEquals(expectedResponseBody.getOriginalUrl(), actualResponse.getOriginalUrl());
        assertEquals(expectedResponseBody.getLocalPath(), actualResponse.getLocalPath());
    }

    @Test(expected = ClassCastException.class)
    public void createNewOriginalURLTestShouldThrowClassCastWhenBodyIsNotCorrect() throws Exception {


        String invalidJsonBody = "xxx some inconvertible string xxx";
        doReturn(new ResponseEntity<>(invalidJsonBody, new HttpHeaders(), HttpStatus.OK))
                .when(mockHttpAdapter).call(anyString(), any(), any(), any());

        dmsDao.createNewOriginalUrl("TESTDOCTYPE", "TESTDOCNUM");
    }

    @Test(expected = HttpClientErrorException.class)
    public void createNewOriginalURLTestShouldThrowHttpWhenStatusIsNot2xx() throws Exception {

        doThrow(HttpClientErrorException.class).when(mockHttpAdapter).call(any(), any(), any(), any());

        dmsDao.createNewOriginalUrl("TESTDOCTYPE", "TESTDOCNUM");
    }
}
