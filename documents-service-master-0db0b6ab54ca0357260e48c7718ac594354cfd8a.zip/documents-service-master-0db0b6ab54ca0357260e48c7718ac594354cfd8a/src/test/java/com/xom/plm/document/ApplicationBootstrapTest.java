package com.xom.plm.document;

import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Test;

import static org.junit.Assert.assertNotNull;

/**
 * Created by tlokeja on 8/10/2017.
 */
public class ApplicationBootstrapTest {

    @Test
    public void objectMapper() throws Exception {
        ApplicationBootstrap app = new ApplicationBootstrap();

        ObjectMapper expectedMapper = new ObjectMapper();
        expectedMapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);

        assertNotNull(app.objectMapper());
    }

    @Test
    public void restTemplate() throws Exception {
        ApplicationBootstrap app = new ApplicationBootstrap();
        assertNotNull(app.restTemplate());
    }

}