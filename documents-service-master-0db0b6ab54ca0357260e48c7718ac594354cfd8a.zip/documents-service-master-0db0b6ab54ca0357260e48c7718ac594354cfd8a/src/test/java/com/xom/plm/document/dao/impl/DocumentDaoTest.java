package com.xom.plm.document.dao.impl;

import com.xom.plm.document.dao.DocumentDao;
import com.xom.plm.document.model.json.Document;
import com.xom.plm.document.model.request.CreateAndLinkRequest;
import com.xom.plm.document.model.request.DocumentTemplate;
import com.xom.plm.document.proxy.HttpAdapter;
import com.xom.plm.document.proxy.SAPAdapter;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.util.UriComponentsBuilder;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;

/**
 * Created by tlokeja on 9/13/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class DocumentDaoTest {

    private DocumentDao documentDao;

    @Mock
    private HttpAdapter mockHttpAdapter;

    @Mock
    private SAPAdapter mockSapAdapter;

    private final String TEST_CREATE_AND_LINK_URL = "http://mockurl/testCreateAndLink";
    private final String TEST_CHECK_IN_URL = "https://hoeg4ew1.na.xom.com:443/xom/dms/original/checkin/{fileId}/{documentType}/{documentNumber}/000/00?sap-client=095";

    @Before
    public void setUp() throws Exception {
        documentDao = new DocumentDaoImpl(mockHttpAdapter, mockSapAdapter, TEST_CREATE_AND_LINK_URL, TEST_CHECK_IN_URL);
    }

    @Test
    public void createAndLinkDocumentTest() throws Exception {

        String mockDocumentType = "mockDocumentType";
        String mockDocumentNumber = "mockDocumentNumber";
        String mockObjectId = "Test_GUID";

        CreateAndLinkRequest mockRequestBody = new CreateAndLinkRequest(new DocumentTemplate(mockDocumentType, mockDocumentNumber), mockObjectId);

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(TEST_CREATE_AND_LINK_URL);

        String expectedResponseType = "TEST_TYPE";
        String expectedResponseNumber = "TEST_NUMBER";

        ResponseEntity<Document> mockResponse =
                new ResponseEntity<>(new Document(expectedResponseType, expectedResponseNumber), new HttpHeaders(), HttpStatus.CREATED);

        doReturn(mockResponse).when(mockHttpAdapter).call(eq(String.valueOf(builder.build().encode().toUri())), eq(HttpMethod.POST), any(), eq(Document.class));

        Document documentResponse = documentDao.createAndLinkDocument(mockRequestBody);

        verify(mockSapAdapter, times(1)).createTokenSAPHeader();
        verify(mockHttpAdapter, times(1)).call(anyString(), eq(HttpMethod.POST), any(), eq(Document.class));

        assertEquals(expectedResponseType, documentResponse.getDocumentType());
        assertEquals(expectedResponseNumber, documentResponse.getDocumentNumber());
    }

    @Test(expected = ClassCastException.class)
    public void createAndLinkDocumentShouldThrowClassCastWhenBodyIsNotCorrect() throws Exception {


        String invalidJsonBody = "xxx some inconvertible string xxx";
        doReturn(new ResponseEntity<>(invalidJsonBody, new HttpHeaders(), HttpStatus.OK))
                .when(mockHttpAdapter).call(anyString(), any(), any(), any());

        documentDao.createAndLinkDocument(new CreateAndLinkRequest());
    }

    @Test(expected = HttpClientErrorException.class)
    public void createAndLinkDocumentShouldThrowHttpWhenStatusIsNot2xx() throws Exception {

        doThrow(HttpClientErrorException.class).when(mockHttpAdapter).call(any(), any(), any(), any());
        documentDao.createAndLinkDocument(new CreateAndLinkRequest());
    }

    @Test
    public void checkInTest() throws Exception {

        String mockDocumentType = "ZXXX";
        String mockDocumentNumber = "2000XXX";
        String mockDocumentFileId = "10BVS_TEST";

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(
                TEST_CHECK_IN_URL.replace("{documentType}", mockDocumentType)
                        .replace("{documentNumber}", mockDocumentNumber).replace("{fileId}", mockDocumentFileId));

        doReturn(new ResponseEntity<>(HttpStatus.OK))
                .when(mockHttpAdapter).call(eq(String.valueOf(builder.build().encode().toUri())), eq(HttpMethod.PUT), any(), eq(String.class));

        documentDao.checkInDocument(mockDocumentType, mockDocumentNumber, mockDocumentFileId);

        verify(mockSapAdapter, times(1)).createTokenSAPHeader();
        verify(mockHttpAdapter, times(1)).call(eq(String.valueOf(builder.build().encode().toUri())), eq(HttpMethod.PUT), any(), eq(String.class));
    }

    @Test(expected = HttpClientErrorException.class)
    public void checkInTestShouldThrowHttpWhenStatusIsNot2xx() throws Exception {

        String mockDocumentType = "ZXXX";
        String mockDocumentNumber = "2000XXX";
        String mockDocumentFileId = "10BVS_TEST";

        doThrow(HttpClientErrorException.class).when(mockHttpAdapter).call(any(), any(), any(), any());

        documentDao.checkInDocument(mockDocumentType, mockDocumentNumber, mockDocumentFileId);
    }


}
