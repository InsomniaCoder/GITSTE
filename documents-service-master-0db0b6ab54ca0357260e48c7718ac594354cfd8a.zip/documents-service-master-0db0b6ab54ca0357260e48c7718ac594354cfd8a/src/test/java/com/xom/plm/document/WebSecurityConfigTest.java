package com.xom.plm.document;

import com.xom.plm.document.controller.DocumentController;
import com.xom.plm.document.model.response.GetOriginalResponse;
import com.xom.plm.document.service.DocumentService;
import com.xom.plm.document.service.TemplateService;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.core.Is.is;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.httpBasic;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Created by tlokeja on 10/24/2017.
 */

@RunWith(SpringRunner.class)
@WebMvcTest(DocumentController.class)
public class WebSecurityConfigTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private DocumentService documentService;

    @MockBean
    private TemplateService templateService;

    @Before

    public void setUp() {
    }

    @Test
    public void rootEndpointWithNoAuthenticationShouldFail() throws Exception {
        mockMvc.perform(get("/").secure(true)
        ).andExpect(status().isUnauthorized());
    }

    @Test
//    @WithMockUser(username = "admin", password = "secrest")
    public void rootEndpointWithAuthenticationShouldPass() throws Exception {
        mockMvc.perform(get("/").with(httpBasic("admin", "secret"))
        ).andExpect(status().isOk()).andExpect(content().string("Document controller hello!"));
    }

    @Test
    public void createEndpointWithNoAuthenticationShouldFail() throws Exception {

        String mockCreateDocRequest = "{\"ITEM_GUID\":\"005056AA1B411ED79DEAA08AD5E440D1\"," +
                " \"ITEM_TYPE\":\"Z001TEST\"}";

        mockMvc.perform(post("/pmoc/documents").contentType("application/json").content(mockCreateDocRequest)
        ).andExpect(status().isUnauthorized());
    }

    @Test
    public void getOriginalEndpointWithNoAuthenticationShouldFail() throws Exception {

        mockMvc.perform(get("/pmoc/documents/original")
                .param("documentType", "ZPP")
                .param("documentNumber", "testnumber")
                .contentType("application/json")
        ).andExpect(status().isUnauthorized());
    }

    @Test
    public void getOriginalEndpointWithAuthenticationShouldPass() throws Exception {

        GetOriginalResponse mockResponse = new GetOriginalResponse("http://testUrl", "C:\\localPath");

        when(documentService.getOriginalUrlAndLocalPath("ZPP", "testnumber"))
                .thenReturn(mockResponse);

        mockMvc.perform(get("/pmoc/documents/original").with(httpBasic("admin", "secret"))
                .contentType("application/json")
                .param("documentType", "ZPP")
                .param("documentNumber", "testnumber")
        ).andExpect(status().isOk())
                .andExpect(jsonPath("$.ORIGINAL_URL", is("http://testUrl")))
                .andExpect(jsonPath("$.LOCAL_PATH", is("C:\\localPath")));
    }

}
